import { VerifyForm } from "@/components/auth/VerifyForm";

export const metadata = {
  title: "Verify Account | GIS Money Transfer",
};

export default function VerifyPage() {
  return <VerifyForm />;
}
