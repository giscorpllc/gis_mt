import { MfaForm } from "@/components/auth/MfaForm";

export const metadata = {
  title: "Two-Factor Authentication | GIS Money Transfer",
};

export default function VerifyMfaPage() {
  return <MfaForm />;
}
